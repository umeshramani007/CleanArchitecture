package com.example.nagarro.util

object Constant {
    const val BASE_URL = "http://api.nytimes.com/svc/mostpopular/v2/"
    const val ARG_ARTICLE = "article"
    const val NO_DATA = "No articles"

}